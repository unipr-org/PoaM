﻿namespace Anagrafiche.Shared
{
    public class SoggettoDto
    {
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string CodiceFiscale { get; set; }
        public DateTime DataDiNascita { get; set; }
    }
}
