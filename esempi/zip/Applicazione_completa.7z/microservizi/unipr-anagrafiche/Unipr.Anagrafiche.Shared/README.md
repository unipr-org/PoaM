﻿README Anagrafiche.Shared
