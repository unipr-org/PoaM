﻿using Imu.Shared;

namespace Imu.ClientHttp.Abstraction
{
    public interface IClientHttp
    {

    }
}
