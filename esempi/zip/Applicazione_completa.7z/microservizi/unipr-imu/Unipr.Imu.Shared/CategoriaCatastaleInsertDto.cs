﻿namespace Imu.Shared
{
    public class CategoriaCatastaleInsertDto
    {
        public required string Codice { get; set; }
        public required string Descrizione { get; set; }
    }
}
