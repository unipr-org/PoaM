﻿namespace Imu.Shared
{
    public class AssociaAnagraficaImmobileDto
    {
        public int IdAnagrafica { get; set; }
        public int IdImmobile { get; set; }
        public decimal Quota { get; set; }
    }
}
