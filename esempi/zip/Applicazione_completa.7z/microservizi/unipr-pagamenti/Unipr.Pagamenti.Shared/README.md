﻿README Pagamenti.Shared
