﻿namespace Pagamenti.ClientHttp.Abstraction
{
    public interface IClientHttp
    {
    }
}
