﻿README Pagamenti.ClientHttp
