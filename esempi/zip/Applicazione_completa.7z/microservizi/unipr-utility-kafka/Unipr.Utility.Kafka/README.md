﻿README Utility.Kafka
